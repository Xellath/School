/*
 * lab1.c
 *
 * Created: 2016-11-01 14:42:40
 *  Author: staff
 * Edited by: Alexander Johansson, Ludwig Ninn
 * Date: 2016-11-24
 */ 


#include <avr/io.h>
#include <stdio.h>
#include <inttypes.h>
#include "numkey/numkey.h"
#include "delay/delay.h"
#include "lcd/lcd.h"

int main(void)
{

	numkey_init();
	lcd_init();
	lcd_clear();
	char input = NO_KEY;
		
	while(1)
	{
		/* 
		// Uppgift 6.3.2 - Writes the char X with a 10 millisecond delay.
		for(int x = 0; x < 6; x++) {
			for(int y = 0; y < 14; y++) {
				lcd_set_cursor_pos(x, y);
				lcd_write(CHR, 'X');
				delay_ms(10);
			}
		}
		
		lcd_clear();
		
		//Uppgift 6.3.3 - Creats a array with chars to the string writer.
		char string[] = "HEJ NINN";
		lcd_write_str(string);
		
		delay_s(1);
		lcd_clear();
		*/
		
		//Uppgift 7.2.3 - Write current pressed numkey. 
		input = numkey_read();
		if (input != NO_KEY) lcd_write(CHR, input);
		while(input == numkey_read()) {
		
		}


	}
}