﻿/*
 * delay.c
 *
 * Created: 2016-11-01
 * Author: Magnus Krampell
 * Edited by: Alexander Johansson, Ludwig Ninn
 * Date: 2016-11-01
 */ 

#include "delay.h"
/*
* Produces 1 microsecond deley.
*/
void delay_1_micros() {
	volatile uint8_t j=0;
	j++;
	j++;
}
/*
*Produces n amount microseconds delay.
*/
void delay_micros(uint8_t n) {
	for(int i= 0; i<n;i++){
		delay_1_micros();
	}
}
/*
*Produces n amount milliseconds delay.
*/
void delay_ms(uint8_t n) {
	for(int i= 0; i<n;i++){
		delay_micros(250);
		delay_micros(250);
		delay_micros(250);
		delay_micros(250);
	}
}
/*
*Produces n amount seconds delay.
*/
void delay_s(uint8_t n) {
	for(int i= 0; i<n;i++){
		delay_ms(250);
		delay_ms(250);
		delay_ms(250);
		delay_ms(250);
	}
}